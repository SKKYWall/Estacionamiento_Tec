using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class PathFinder : MonoBehaviour
{
    [SerializeField] Vector2 startCords;
    public Vector2 StartCords { get { return startCords; } }
    [SerializeField] Vector2 targetCords;
    public Vector2 TargetCords { get { return targetCords; } }

    Nodo startNodo;
    Nodo targetNodo;
    Nodo currentNodo;

    Queue<Nodo> frontier = new Queue<Nodo>();
    Dictionary<Vector2, Nodo> reached = new Dictionary<Vector2, Nodo>();

    GridManager gridManager;
    Dictionary<Vector2, Nodo> grid = new Dictionary<Vector2, Nodo>();

    Vector2[] searchOrder = { Vector2.right, Vector2.up, Vector2.left, Vector2.down };
    int currentSeekerID = -1;

    private void Awake()
    {
        gridManager = FindAnyObjectByType<GridManager>();
        if (gridManager != null)
        {
            grid = gridManager.Grid;
        }
    }

    public List<Nodo> GetNewPath()
    {
        return GetNewPath(startCords, currentSeekerID);
    }

    public List<Nodo> GetNewPath(Vector2 coordinates, int seekerID)
    {
        targetNodo = grid[targetCords];
        this.currentSeekerID = seekerID;
        gridManager.ResetNodos();
        BreadthFirstSearch(coordinates);
        return BuildPath();
    }

    void BreadthFirstSearch(Vector2 coordinates)
    {
        frontier.Clear();
        reached.Clear();

        bool isRunning = true;

        frontier.Enqueue(grid[coordinates]);
        reached.Add(coordinates, grid[coordinates]);

        while (frontier.Count > 0 && isRunning == true)
        {
            currentNodo = frontier.Dequeue();
            currentNodo.explored = true;
            ExploreNeighbors();
            if (currentNodo.cords == targetCords)
            {
                isRunning = false;
            }
        }

    }


    void ExploreNeighbors()
    {
        foreach (Vector2 direction in searchOrder)
        {
            if (!DireccionPermitida(direction, currentNodo.direccionesPermitidas))
            {
                Debug.Log($"Nodo {currentNodo.cords} -> {direction} NO permitido por direcciones.");
                continue;
            }

            Vector2 neighborCords = currentNodo.cords + direction;
            if (!grid.ContainsKey(neighborCords))
            {
                Debug.Log($"Nodo {currentNodo.cords} -> {neighborCords} NO existe en grid.");
                continue;
            }

            Nodo neighborNode = grid[neighborCords];

            if (!reached.ContainsKey(neighborNode.cords) && IsNodeWalkable(neighborNode, currentSeekerID))
            {
                neighborNode.connectTo = currentNodo;
                reached.Add(neighborNode.cords, neighborNode);
                frontier.Enqueue(neighborNode);
                Debug.Log($"Nodo {currentNodo.cords} -> {neighborNode.cords} agregado a frontier");
            }
            else
            {
                Debug.Log($"Nodo {currentNodo.cords} -> {neighborNode.cords} NO agregado a frontier (ya alcanzado o no caminable)");
            }
        }
    }



    bool DireccionPermitida(Vector2 dir, Direccion permitidas)
    {
        if (permitidas == Direccion.Ninguna) return true;

        if (dir == Vector2.up) return permitidas.HasFlag(Direccion.Arriba);
        if (dir == Vector2.right) return permitidas.HasFlag(Direccion.Derecha);
        if (dir == Vector2.down) return permitidas.HasFlag(Direccion.Abajo);
        if (dir == Vector2.left) return permitidas.HasFlag(Direccion.Izquierda);

        return false;
    }


    List<Nodo> BuildPath()
    {
        List<Nodo> path = new List<Nodo>();
        Nodo currentNodo = targetNodo;

        path.Add(currentNodo);
        currentNodo.path = true;

        while (currentNodo.connectTo != null)
        {
            currentNodo = currentNodo.connectTo;
            path.Add(currentNodo);
            currentNodo.path = true;
        }

        path.Reverse();
        return path;
    }

    public void NotifyReceivers()
    {
        BroadcastMessage("RecalculatePath", false, SendMessageOptions.DontRequireReceiver);
    }

    public void SetNewDestination(Vector2 startCoordinates, Vector2 targetCoordinates, int agentID)
    {
        startCords = startCoordinates;
        targetCords = targetCoordinates;
        startNodo = grid[this.startCords];
        targetNodo = grid[this.targetCords];
        GetNewPath(startCoordinates, agentID);
    }

    bool IsNodeWalkable(Nodo nodo, int seekerID)
    {
        return nodo.walkable || nodo.ownerID == seekerID;
    }
}
