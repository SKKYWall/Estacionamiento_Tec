using TMPro;
using UnityEngine;

public class Timer : MonoBehaviour
{
    public float counter = 0f; // Initial time in seconds
    public TMP_Text timerText; // Reference to the UI Text element

    void Update()
    {

        counter += Time.deltaTime;
        DisplayTime(counter);

    }

    void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1; // To ensure the timer starts at the specified number and not 59.999
        float minutes = Mathf.FloorToInt(timeToDisplay / 60) -1;
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);

        // Format the time as MM:SS
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

}
