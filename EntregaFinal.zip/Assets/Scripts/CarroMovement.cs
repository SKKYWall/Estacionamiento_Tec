using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NativeWebSocket;
using System.Linq;
using TMPro;

public class CarroMovement : MonoBehaviour
{
    [Header("Movimiento")]
    public float movementSpeed = 2.5f;
    [SerializeField] int agentID;
    public float destroyDistance = 20.0f;
    public float delay = 5.0f;
    private WebSocket ws;
    private GridManager gridManager;
    private Coroutine moveCoroutine;

    async void Start()
    {
        gridManager = FindObjectOfType<GridManager>();

        ws = new WebSocket("ws://localhost:8765");

        ws.OnOpen += async () =>
        {
            Debug.Log($"Carro {agentID} conectado");

            RegisterMessage register = new RegisterMessage
            {
                type = "register",
                id = agentID
            };

            await ws.SendText(JsonUtility.ToJson(register));
        };

        ws.OnMessage += (bytes) =>
        {
            string message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("WS: " + message);

            PathMessage msg = JsonUtility.FromJson<PathMessage>(message);

            if (msg.type != "path" || msg.id != agentID)
                return;

            if (moveCoroutine != null)
                StopCoroutine(moveCoroutine);

            moveCoroutine = StartCoroutine(FollowPath(msg.path));
        };

        ws.OnError += e => Debug.LogError(e);
        ws.OnClose += e => Debug.Log("WebSocket cerrado");

        await ws.Connect();
    }

    void Update()
    {
        #if !UNITY_WEBGL || UNITY_EDITOR
                ws.DispatchMessageQueue();
        #endif

        float dist = Vector3.Distance(Camera.main.transform.position, transform.position);

        if (dist>destroyDistance)
        {
            if (this.gameObject != null)
            {
                sendTerminated();
                Destroy(this.gameObject);
            }
        }
        

    }

    IEnumerator FollowPath(int[] nodes)
    {
        Debug.Log($"Agente {agentID}: siguiendo path con {nodes.Length} nodos");
        Vector2 currentCoords = gridManager.NodeToCoord(nodes[0]);

        // ocupar nodo inicial
        gridManager.BlockNode(currentCoords);

        for (int i = 1; i < nodes.Length; i++)
        {
            Vector3 start = transform.position;
            Vector3 end = gridManager.NodeToWorld(nodes[i]);
            Vector2 nextCoords = gridManager.NodeToCoord(nodes[i]);

            while (nodes[i]<25 && !gridManager.BlockNode(nextCoords))
            {
                yield return null; // esperar frame
            }
            transform.LookAt(end);

            float t = 0f;
            while (t < 1f)
            {
                t += Time.deltaTime * movementSpeed;
                transform.position = Vector3.Lerp(start, end, t);
                yield return null;
            }
            if(i>1)
            {
                currentCoords = gridManager.NodeToCoord(nodes[i-2]);
                gridManager.ReleaseNode(currentCoords);
            }
            if (i == nodes.Length -1)
            {
                currentCoords = gridManager.NodeToCoord(nodes[i-1]);
                gridManager.ReleaseNode(currentCoords);
            }
        }

        Debug.Log($"Agente {agentID}: Ha llegado a su destino");
        /*
        
        for (int i = 1; i < path.Count; i++)
        {
            Vector3 startPosition = selectedUnit.position;
            Vector2Int nextCoords = path[i].cords;
            Vector3 endPosition = gridManager.GetPositionFromCoordinates(nextCoords);

            // Bloquear nodo al que vamos
            gridManager.SetNodeWalkable(nextCoords, false);

            float travelPercent = 0f;
            Vector3 direction = (endPosition - startPosition).normalized;

            if (direction != Vector3.zero)
                selectedUnit.rotation = Quaternion.LookRotation(direction);

            while (travelPercent < 1f)
            {
                // Raycast de seguridad
                Vector3 rayOrigin = selectedUnit.position + (direction * 0.8f) + (Vector3.up * 0.5f);
                int layerMask = LayerMask.GetMask("Vehiculos");

                // Nota: El rayo ignora el colisionador propio si está bien configurado el origen
                if (Physics.Raycast(rayOrigin, direction, out RaycastHit hit, distanciaSeguridad, layerMask))
                {
                    yield return null;
                    continue;
                }

                travelPercent += Time.deltaTime * movementSpeed;
                selectedUnit.position = Vector3.Lerp(startPosition, endPosition, travelPercent);
                yield return null;
            }

            // Liberar nodo viejo si no es parte del destino final bloqueado
            Vector2Int oldCoords = gridManager.GetCoordinatesFromPosition(startPosition);
            if (oldCoords != targetPos && oldCoords != entryNode)
            {
                gridManager.SetNodeWalkable(oldCoords, true);
            }
        }

        // --- AJUSTE FINAL ---
        selectedUnit.position = gridManager.GetPositionFromCoordinates(targetPos);
        */
        yield return new WaitForSeconds(delay);
        sendFinish();
    }

    async void OnApplicationQuit()
    {
        if (ws != null)
            await ws.Close();
    }

    public void SetAgentID(int id)
    {
        agentID = id;
    }

    async void sendFinish()
    {
        RegisterMessage register = new RegisterMessage
            {
                type = "arrived",
                id = agentID
            };

        await ws.SendText(JsonUtility.ToJson(register));
    }

    async void sendTerminated()
    {
        RegisterMessage register = new RegisterMessage
            {
                type = "terminated",
                id = agentID
            };

        await ws.SendText(JsonUtility.ToJson(register));
    }
}

[System.Serializable]
public class RegisterMessage
{
    public string type;
    public int id;
}

[System.Serializable]
public class PathMessage
{
    public string type;
    public int id;
    public int[] path;
}

