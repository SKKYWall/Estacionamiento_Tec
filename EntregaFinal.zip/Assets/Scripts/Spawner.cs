using TMPro;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject SpawnPrefab = null;
    public float spawnTime = 5.0f;
    private float movementSpeed = 2.5f;
    private float delay = 5.0f;
    private float nextSpawn = 0f;
    public TMP_InputField inputspawn;
    public TMP_InputField inputSpeed;
    public TMP_InputField inputDelay;

    private int nextAgentID = 1; 

    void Start()
    {
        nextSpawn = 0f;
    }

    void Update()
    {
        nextSpawn += Time.deltaTime;

        if (nextSpawn > spawnTime)
        {
            GameObject car = Instantiate(
                SpawnPrefab,
                transform.position,
                transform.rotation
            );
            CarroMovement movement = car.GetComponent<CarroMovement>();
            if (movement != null)
            {
                movement.SetAgentID(nextAgentID);
                Debug.Log($"Carro spawneado con ID {nextAgentID}");
                movement.delay = delay;
                movement.movementSpeed = movementSpeed;
                nextAgentID++;
            }
            else
            {
                Debug.LogError("El prefab no tiene CarroMovement");
            }

            nextSpawn = 0f;
        }
    }

    public void ReadInput()
    {
        float userInput = float.Parse(inputspawn.text);
        spawnTime = userInput;
        //inputspawn.ActivateInputField();
    }
    public void ReadInputSpeed()
    {
        float userInput = float.Parse(inputSpeed.text);
        movementSpeed = userInput;
       // inputSpeed.ActivateInputField();
    }
    public void ReadInputDelay()
    {
        float userInput = float.Parse(inputDelay.text);
        delay = userInput;
        //inputDelay.ActivateInputField();
    }
}
