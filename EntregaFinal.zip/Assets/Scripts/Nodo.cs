using UnityEditor.Experimental.GraphView;
using UnityEngine;


[System.Flags]
public enum Direccion
{
    Ninguna = 0,
    Arriba = 1 << 0,
    Derecha = 1 << 1,
    Abajo = 1 << 2,
    Izquierda = 1 << 3
}
public class Nodo
{
    public Vector2 cords;
    public bool walkable;
    public bool explored;
    public bool path;
    public Nodo connectTo;
    public int ownerID = -1;

    public Direccion direccionesPermitidas = Direccion.Ninguna;

    public Nodo(Vector2 cords, bool walkable)
    {
        this.cords = cords;
        this.walkable = walkable;
    }
}