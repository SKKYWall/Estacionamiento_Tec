using UnityEngine;

public class CarDestroy : MonoBehaviour
{
    public float destroyDistance = 20.0f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float dist = Vector3.Distance(Camera.main.transform.position, transform.position);

        if (dist>destroyDistance)
        {
            if (this.gameObject != null)
            {
                Destroy(this.gameObject);
            }
        }
    }
}
