using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    [SerializeField] Vector2Int gridSize;
    [SerializeField] int unityGridSize;
    [SerializeField] LayerMask obstacleLayer;
    public int UnityGridSize { get { return unityGridSize; } }

    Dictionary<Vector2, Nodo> grid = new Dictionary<Vector2, Nodo>();
    public Dictionary<Vector2, Nodo> Grid { get { return grid; } }
    Dictionary<int, Vector3> nodeToWorld = new Dictionary<int, Vector3>();


    private void Awake()
    {
        InitNodePositions();
        CreateGrid();
        ConfigurarSentidos();
        
    }

    public Nodo GetNodo(Vector2 coordinates)
    {
        if (grid.ContainsKey(coordinates))
        {
            return grid[coordinates];
        }
        return null;
    }

    public bool BlockNode(Vector2 coordinates)
    {
        if (grid.ContainsKey(coordinates) && grid[coordinates].walkable)
        {
            grid[coordinates].walkable = false;
            return true;
        }
        else
        {
            return false;
        }
    }

    public void ReleaseNode(Vector2 coordinates)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].walkable = true;
        }
    
    }

    public void ResetNodos()
    {
        foreach (KeyValuePair<Vector2, Nodo> entry in grid)
        {
            entry.Value.connectTo = null;
            entry.Value.explored = false;
            entry.Value.path = false;
        }
    }

    public Vector2Int GetCoordinatesFromPosition(Vector3 position)
    {
        Vector3 relativePos = position - transform.position;
        Vector2Int coordinates = new Vector2Int();

        coordinates.x = Mathf.RoundToInt(relativePos.x);
        coordinates.y = Mathf.RoundToInt(relativePos.z);

        return coordinates;
    }

    public Vector3 GetPositionFromCoordinates(Vector2 coordinates)
    {
        Vector3 position = new Vector3();
 
        position.x = coordinates.x;
        position.z = coordinates.y;

        return position + transform.position;
    }

    public void SetNodeWalkable(Vector2 coordinates, bool isWalkable)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].walkable = isWalkable;
            if (isWalkable) grid[coordinates].ownerID = -1;
        }
    }
    void InitNodePositions()
    {
        // Camino principal (28 nodos)
        nodeToWorld[0]  = new Vector3(18, 0, -7);
        nodeToWorld[1]  = new Vector3(0, 0, -7);
        nodeToWorld[2]  = new Vector3(0, 0, 4.5f);
        nodeToWorld[3]  = new Vector3(3, 0, 4.5f);
        nodeToWorld[4]  = new Vector3(6, 0, 4.5f);
        nodeToWorld[5]  = new Vector3(9, 0, 4.5f);
        nodeToWorld[6]  = new Vector3(12, 0, 4.5f);
        nodeToWorld[7]  = new Vector3(15, 0, 4.5f);
        nodeToWorld[8]  = new Vector3(15, 0, 9);
        nodeToWorld[9]  = new Vector3(12, 0, 9);
        nodeToWorld[10]  = new Vector3(9, 0, 9);
        nodeToWorld[11]  = new Vector3(6, 0, 9);
        nodeToWorld[12]  = new Vector3(3, 0, 9);
        nodeToWorld[13]  = new Vector3(0, 0, 9);
        nodeToWorld[14]  = new Vector3(-3, 0, 9);
        nodeToWorld[15]  = new Vector3(-6, 0, 9);
        nodeToWorld[16]  = new Vector3(-9, 0, 9);
        nodeToWorld[17]  = new Vector3(-12, 0, 9);
        nodeToWorld[18]  = new Vector3(-15, 0, 9);
        nodeToWorld[19]  = new Vector3(-18, 0, 9);
        nodeToWorld[20]  = new Vector3(-18, 0, 4.5f);
        nodeToWorld[21]  = new Vector3(-15, 0, 4.5f);
        nodeToWorld[22]  = new Vector3(-12, 0, 4.5f);
        nodeToWorld[23]  = new Vector3(-9, 0, 4.5f);
        nodeToWorld[24]  = new Vector3(-6, 0, 4.5f);
        nodeToWorld[25]  = new Vector3(-3, 0, 4.5f);
        nodeToWorld[26]  = new Vector3(-3, 0, -7);
        nodeToWorld[27]  = new Vector3(-50, 0, -7);   

        nodeToWorld[28]  = new Vector3(3, 0, 0);
        nodeToWorld[29]  = new Vector3(6, 0, 0);
        nodeToWorld[30]  = new Vector3(9, 0, 0);
        nodeToWorld[31]  = new Vector3(12, 0, 0);
        nodeToWorld[32]  = new Vector3(15, 0, 0);

        nodeToWorld[33]  = new Vector3(15, 0, 14);
        nodeToWorld[34]  = new Vector3(12, 0, 14);
        nodeToWorld[35]  = new Vector3(9, 0, 14);
        nodeToWorld[36]  = new Vector3(6, 0, 14);
        nodeToWorld[37]  = new Vector3(3, 0, 14);

        nodeToWorld[38]  = new Vector3(-6, 0, 14);
        nodeToWorld[39]  = new Vector3(-9, 0, 14);
        nodeToWorld[40]  = new Vector3(-12, 0, 14);
        nodeToWorld[41]  = new Vector3(-15, 0, 14);
        nodeToWorld[42]  = new Vector3(-18, 0, 14);

        nodeToWorld[43]  = new Vector3(-18, 0, 0);
        nodeToWorld[44]  = new Vector3(-15, 0, 0);
        nodeToWorld[45]  = new Vector3(-12, 0, 0);
        nodeToWorld[46]  = new Vector3(-9, 0, 0);
        nodeToWorld[47]  = new Vector3(-6, 0, 0);

    }

    
    public Vector2 NodeToCoord(int nodeId)
    {
        if (!nodeToWorld.ContainsKey(nodeId))
        {
            Debug.LogError($"Nodo {nodeId} no existe");
            return Vector2.zero;
        }

        return new Vector2(nodeToWorld[nodeId].x, nodeToWorld[nodeId].z);
    }
    public Vector3 NodeToWorld(int nodeID)
    {
        return nodeToWorld[nodeID];
    }

    private void CreateGrid()
    {
        for (int x = 0; x < nodeToWorld.Count; x++)
        {
            Vector2 cords = new Vector2(nodeToWorld[x].x, nodeToWorld[x].z);
            /*
            Vector3 worldPos = GetPositionFromCoordinates(cords);

            Vector3 checkPos = worldPos;
            checkPos.y = 1.0f;

            Collider[] colliders = Physics.OverlapSphere(checkPos, 1f, obstacleLayer);
            bool isBlocked = colliders.Length > 0;

            if (isBlocked)
            {
                foreach (var col in colliders)
                {
                    Debug.Log($"<color=red>Nodo {cords} BLOQUEADO por:</color> {col.name} en la capa {LayerMask.LayerToName(col.gameObject.layer)}");
                }
            }
            */
            grid.Add(cords, new Nodo(cords, true));
            Debug.Log(grid[cords].cords);
        }
    }

    public void SetNodeOwner(Vector2Int coordinates, int agentID)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].ownerID = agentID;
        }
    }

    private void OnDrawGizmos()
    {
        if (grid == null) return;

        foreach (var item in grid)
        {
            Nodo n = item.Value;
            Vector3 pos = GetPositionFromCoordinates(item.Key);

            // Color base
            if (n.ownerID != -1) Gizmos.color = Color.blue;
            else if (!n.walkable) Gizmos.color = Color.red;
            else if (n.direccionesPermitidas == Direccion.Ninguna) Gizmos.color = Color.white;
            else if (n.direccionesPermitidas == Direccion.Arriba) Gizmos.color = Color.blue;
            else if (n.direccionesPermitidas == Direccion.Derecha) Gizmos.color = Color.magenta;
            else if (n.direccionesPermitidas == Direccion.Abajo) Gizmos.color = Color.yellow;
            else if (n.direccionesPermitidas == Direccion.Izquierda) Gizmos.color = Color.green;

            else Gizmos.color = Color.gray;

            Gizmos.DrawSphere(pos, 0.5f);

            // Dibujar flechas por cada dirección permitida
            Gizmos.color = Color.black;

            if (n.direccionesPermitidas.HasFlag(Direccion.Arriba))
                Gizmos.DrawRay(pos, Vector3.forward * 1.2f);

            if (n.direccionesPermitidas.HasFlag(Direccion.Abajo))
                Gizmos.DrawRay(pos, Vector3.back * 1.2f);

            if (n.direccionesPermitidas.HasFlag(Direccion.Derecha))
                Gizmos.DrawRay(pos, Vector3.right * 1.2f);

            if (n.direccionesPermitidas.HasFlag(Direccion.Izquierda))
                Gizmos.DrawRay(pos, Vector3.left * 1.2f);
        }
    }


    public void ConfigurarSentidos()
    {
        foreach (var item in grid)
        {
            Vector2 c = item.Key;
            Nodo n = item.Value;


            n.direccionesPermitidas = Direccion.Ninguna;

            /*

            // ==========================================
            // 1. PUNTOS DE GIRO Y DECISIÓN (ALTA PRIORIDAD)
            // ==========================================

            // Punto de bajada para cambiar de carril
            if (c.x == 9 && c.y == 4)
            {
                n.direccionesPermitidas = Direccion.Abajo | Direccion.Izquierda;
                continue;
            }

            // Recepción en carril inferior y giro
            if (c.x == 9 && c.y == 3)
            {
                n.direccionesPermitidas = Direccion.Derecha;
                continue;
            }

            // Punto 30,3: Seguir derecha o subir para retornar
            if (c.x == 30 && c.y == 3)
            {
                n.direccionesPermitidas = Direccion.Derecha | Direccion.Arriba;
                continue;
            }

            // Nodo intermedio que permite seguir derecho y subir hacia 30,3
            if (c.y == 3 && c.x >= 11 && c.x <= 29)
            {
                n.direccionesPermitidas = Direccion.Derecha | Direccion.Arriba;
                continue;
            }

            // Punto 30,4: Integración al flujo de la izquierda
            if (c.x == 30 && c.y == 4)
            {
                n.direccionesPermitidas = Direccion.Izquierda;
                continue;
            }

            // ==========================================
            // 2. REGLAS DE FILAS (CARRETERAS)
            // ==========================================

            // Solo nodos de fila 3 fuera de rangos especiales
            if (c.y == 3 && (c.x < 11 || c.x > 30))
            {
                n.direccionesPermitidas = Direccion.Derecha;
                continue;
            }

            if (c.y == 4)
            {
                n.direccionesPermitidas = Direccion.Izquierda;
                continue;
            }

            // ==========================================
            // 3. CAJONES Y ZONA DE MANIOBRA
            // ==========================================

            if (c.y == 6 || c.y == 11)
            {
                n.direccionesPermitidas = Direccion.Abajo | Direccion.Arriba;
            }
            else if (c.x == 18 && c.y >= 5 && c.y <= 7)
            {
                n.direccionesPermitidas = Direccion.Arriba;
            }
            else if (c.x == 18 && c.y == 8)
            {
                n.direccionesPermitidas = Direccion.Derecha;
            }
            else if (c.y == 8)
            {
                if (c.x >= 12 && c.x <= 22) n.direccionesPermitidas = Direccion.Derecha | Direccion.Abajo;
                else if (c.x == 23) n.direccionesPermitidas = Direccion.Arriba | Direccion.Abajo;
            }
            else if (c.y == 7 && c.x >= 19 && c.x <= 23)
            {
                n.direccionesPermitidas = Direccion.Abajo;
            }
            else if (c.x == 17 && c.y >= 5 && c.y <= 8)
            {
                n.direccionesPermitidas = Direccion.Abajo;
            }*/
        }

        Debug.Log("=== DIRECCIONES PERMITIDAS DE TODOS LOS NODOS ===");
        foreach (var item in grid)
        {
            Vector2 c = item.Key;
            Nodo n = item.Value;

            string dirs = "";
            if (n.direccionesPermitidas.HasFlag(Direccion.Arriba)) dirs += "Arriba ";
            if (n.direccionesPermitidas.HasFlag(Direccion.Derecha)) dirs += "Derecha ";
            if (n.direccionesPermitidas.HasFlag(Direccion.Abajo)) dirs += "Abajo ";
            if (n.direccionesPermitidas.HasFlag(Direccion.Izquierda)) dirs += "Izquierda ";
            if (dirs == "") dirs = "Ninguna";
        }

    }

}

public class GraphNode
{
    public int id;
    public Vector3 worldPosition;
    public List<int> neighbors = new List<int>();
}
