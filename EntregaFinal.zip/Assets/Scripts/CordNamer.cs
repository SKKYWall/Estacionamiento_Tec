using System;
using UnityEngine;

[ExecuteAlways]
public class CordNamer : MonoBehaviour
{
    public Vector2Int cords = new Vector2Int();
    GridManager gridManager;

    private void Awake()
    {
        gridManager = FindObjectOfType<GridManager>();

        DisplayCords();
    }

    private void Update()
    {
        DisplayCords();
        transform.name = cords.ToString();
    }
    private void DisplayCords()
    {
        if(!gridManager){return;}
        cords.x = Mathf.RoundToInt(transform.position.x);
        cords.y = Mathf.RoundToInt(transform.position.z);
        
    }
}
