using System;
using UnityEngine;

[ExecuteAlways]
public class Labeller : MonoBehaviour
{
    Vector2Int cords = new Vector2Int();
    GridManager gridManager;

    private void Awake()
    {
        gridManager = FindObjectOfType<GridManager>();

        DisplayCords();
    }

    private void Update()
    {
        DisplayCords();
        transform.name = cords.ToString();
    }
    private void DisplayCords()
    {
        if(!gridManager){return;}
        cords.x = Mathf.RoundToInt(transform.position.x / gridManager.UnityGridSize);
        cords.y = Mathf.RoundToInt(transform.position.z / gridManager.UnityGridSize);
        
    }
}
