from osbrain import Agent
import heapq

class Car(Agent):
    def on_init(self):
        self.car_id = None
        self.goal = {"x": None, "y": None}

    def set_id(self, cid):
        self.car_id = cid

    def set_goal(self, goal):
        self.goal = goal
        self.log_info(f"Agente {self.car_id} direccionando a {self.goal}")

    def a_starAdyaciencia(self, graph, start, goal):
        open_set = []
        heapq.heappush(open_set, (0, start))

        came_from = {}
        g_score = {start: 0}

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == goal:
                return self.reconstruir_camino(came_from, current)

            for neighbor in graph[current]:
                tentative = g_score[current] + 1

                if tentative < g_score.get(neighbor, float("inf")):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative
                    f = tentative + self.heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f, neighbor))

        return None

    def reconstruir_camino(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        return path[::-1]
    
    def heuristic(self, a, b):
        return abs(a - b)

