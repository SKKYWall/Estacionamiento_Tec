import asyncio
import json
import random
from osbrain import run_agent, run_nameserver
from Car import Car
import websockets

cars = {}         
connected_sockets = {} 

cajones_disponibles = []
for i in range(20):
    cajones_disponibles.append(i+28)

random.shuffle(cajones_disponibles)
assign = dict()
agent = dict()

async def handler(ws):
    print("Cliente conectado")

    try:
        async for message in ws:
            data = json.loads(message)

            if data["type"] == "register":
                cid = data["id"]
                connected_sockets[ws] = cid

                if cid not in cars:
                    agent[cid] = run_agent(f"car_{cid}", base=Car)
                    agent[cid].set_id(cid)
                    cars[cid] = agent[cid]
                    print(f"Agente {cid} creado")

                if cajones_disponibles:
                    node = cajones_disponibles.pop()
                    path = agent[cid].a_starAdyaciencia(graph, 0, node)
                    goal = {
                        "type": "path",
                        "id": cid,
                        "path": path
                    }

                    cars[cid].safe_call("set_goal", goal)
                    assign[cid] = node

                    await ws.send(json.dumps(goal))
                    print(f"Destino {node} enviado a {cid}: {goal}")

            elif data["type"] == "arrived":
                cid = data["id"]
                connected_sockets[ws] = cid
                if assign[cid] is not None:
                    path = agent[cid].a_starAdyaciencia(graph, assign[cid], 27)
                    goal = {
                        "type": "path",
                        "id": cid,
                        "path": path
                    }
                await ws.send(json.dumps(goal))
                print(f"Destino enviado a {cid}: {goal}")

            elif data["type"] == "terminated":
                cid = data["id"]
                cajones_disponibles.append(assign.pop(cid))
                del agent[cid]
                print(f"Agente {cid} terminated")
                

    except websockets.exceptions.ConnectionClosed:
        print("Cliente desconectado")

    finally:
        cid = connected_sockets.get(ws)
        if cid:
            print(f"Limpieza del agente {cid}")
            cars.pop(cid, None)
        connected_sockets.pop(ws, None)

async def main():
    print("Iniciando NameServer")
    ns = run_nameserver()

    print("Servidor WebSocket en ws://localhost:8765")
    async with websockets.serve(handler, "localhost", 8765):
        await asyncio.Future() 


def build_custom_graph():
    graph = {}

    TOTAL_NODES = 48
    MAIN_CHAIN = 28
    EXTRA_NODES = 10

    # Inicializar nodos vacíos
    for i in range(TOTAL_NODES):
        graph[i] = []

    for i in range(MAIN_CHAIN - 1):
        graph[i].append(i + 1)

    main_index = 3  # empezamos después de los primeros 3

    for extra_node in range(MAIN_CHAIN, EXTRA_NODES+MAIN_CHAIN):
        graph[extra_node].append(main_index)
        graph[main_index].append(extra_node)

        main_index += 1  # siguiente nodo de la lista
    main_index +=2
    
    for extra_node in range(MAIN_CHAIN +EXTRA_NODES, TOTAL_NODES):
        graph[extra_node].append(main_index)
        graph[main_index].append(extra_node)

        main_index += 1  # siguiente nodo de la lista

    return graph

graph = build_custom_graph()

if __name__ == "__main__":
    print(cajones_disponibles)
    print(graph)
    asyncio.run(main())
