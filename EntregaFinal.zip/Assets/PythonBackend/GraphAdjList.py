class GraphAdjList:
    grid = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

    def __init__(self):
        self.graph = {}

    def add_node(self, node):
        if node not in self.graph:
            self.graph[node] = []

    def add_edge(self, from_node, to_node, cost=1):
        self.graph[from_node].append((to_node, cost))

    def neighbors(self, node):
        return self.graph.get(node, [])

    def build_graph_from_grid(grid, GRID_WIDTH, GRID_HEIGHT):
        g = GraphAdjList()

        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                if grid[y][x] == 1:
                    continue

                g.add_node((x, y))

                for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < GRID_WIDTH and 0 <= ny < GRID_HEIGHT:
                        if grid[ny][nx] == 0:
                            g.add_edge((x, y), (nx, ny), 1)

        return g
