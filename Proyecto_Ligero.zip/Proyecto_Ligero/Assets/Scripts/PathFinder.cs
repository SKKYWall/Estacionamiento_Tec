using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class PathFinder : MonoBehaviour
{
    [SerializeField] Vector2Int startCords;
    public Vector2Int StartCords { get { return startCords; } }
    [SerializeField] Vector2Int targetCords;
    public Vector2Int TargetCords { get { return targetCords; } }

    Nodo startNodo;
    Nodo targetNodo;
    Nodo currentNodo;

    Queue<Nodo> frontier = new Queue<Nodo>();
    Dictionary<Vector2Int, Nodo> reached = new Dictionary<Vector2Int, Nodo>();

    GridManager gridManager;
    Dictionary<Vector2Int, Nodo> grid = new Dictionary<Vector2Int, Nodo>();

    Vector2Int[] searchOrder = { Vector2Int.right, Vector2Int.up, Vector2Int.left, Vector2Int.down };
    int currentSeekerID = -1;

    private void Awake()
    {
        gridManager = FindAnyObjectByType<GridManager>();
        if (gridManager != null)
        {
            grid = gridManager.Grid;
        }
    }

    public List<Nodo> GetNewPath()
    {
        return GetNewPath(startCords, currentSeekerID);
    }

    public List<Nodo> GetNewPath(Vector2Int coordinates, int seekerID)
    {
        this.currentSeekerID = seekerID;
        gridManager.ResetNodos();
        BreadthFirstSearch(coordinates);
        return BuildPath();
    }

    void BreadthFirstSearch(Vector2Int coordinates)
    {
        frontier.Clear();
        reached.Clear();

        bool isRunning = true;

        frontier.Enqueue(grid[coordinates]);
        reached.Add(coordinates, grid[coordinates]);

        while (frontier.Count > 0 && isRunning == true)
        {
            currentNodo = frontier.Dequeue();
            currentNodo.explored = true;
            ExploreNeighbors();
            if (currentNodo.cords == targetCords)
            {
                isRunning = false;
            }
        }

    }

    void ExploreNeighbors()
    {
        List<Nodo> neighbors = new List<Nodo>();

        foreach (Vector2Int direction in searchOrder)
        {
            Vector2Int neighborCords = currentNodo.cords + direction;
            if (grid.ContainsKey(neighborCords))
            {
                Nodo neighborNode = grid[neighborCords];
                /*
                if (currentNodo.sentidoObligatorio != Vector2Int.zero && direction != currentNodo.sentidoObligatorio)
                {
                    continue;
                }
                */

                neighbors.Add(neighborNode);
            }
        }

        foreach (Nodo neighbor in neighbors)
        {
            if (!reached.ContainsKey(neighbor.cords) && IsNodeWalkable(neighbor, currentSeekerID))
            {
                neighbor.connectTo = currentNodo;
                reached.Add(neighbor.cords, neighbor);
                frontier.Enqueue(neighbor);
            }
        }
    }

    List<Nodo> BuildPath()
    {
        List<Nodo> path = new List<Nodo>();
        Nodo currentNodo = targetNodo;

        path.Add(currentNodo);
        currentNodo.path = true;

        while (currentNodo.connectTo != null)
        {
            currentNodo = currentNodo.connectTo;
            path.Add(currentNodo);
            currentNodo.path = true;
        }

        path.Reverse();
        return path;
    }

    public void NotifyReceivers()
    {
        BroadcastMessage("RecalculatePath", false, SendMessageOptions.DontRequireReceiver);
    }

    public void SetNewDestination(Vector2Int startCoordinates, Vector2Int targetCoordinates, int agentID)
    {
        startCords = startCoordinates;
        targetCords = targetCoordinates;
        startNodo = grid[this.startCords];
        targetNodo = grid[this.targetCords];
        GetNewPath(startCoordinates, agentID);
    }

    bool IsNodeWalkable(Nodo nodo, int seekerID)
    {
        return nodo.walkable || nodo.ownerID == seekerID;
    }
}
