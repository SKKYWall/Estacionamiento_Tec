using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class Nodo
{
    public Vector2Int cords;
    public bool walkable;
    public bool explored;
    public bool path;
    public Nodo connectTo;

    public int ownerID = -1;

    public Vector2Int sentidoObligatorio = Vector2Int.zero;
    public Nodo(Vector2Int cords, bool walkable)
    {
        this.cords = cords;
        this.walkable = walkable;
    }
}
