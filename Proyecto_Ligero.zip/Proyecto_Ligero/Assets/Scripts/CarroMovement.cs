using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NativeWebSocket;

public class CarroMovement : MonoBehaviour
{
    [SerializeField] float movementSpeed = 2.5f;
    [SerializeField] float distanciaSeguridad = 2.5f;
    [SerializeField] int agentID;

    public Transform selectedUnit;
    bool unitSelected = false;

    List<Nodo> path = new List<Nodo>();

    PathFinder pathFinding;
    GridManager gridManager;

    WebSocket ws;

    async void Start()
    {
        gridManager = FindObjectOfType<GridManager>();
        pathFinding = FindObjectOfType<PathFinder>();

        unitSelected = true;

        ws = new WebSocket("ws://localhost:8765");

        Debug.Log("Connecting to WebSocket...");

        ws.OnMessage += (bytes) =>
        {
            Debug.Log("WebSocket message received!");
            string message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("WS: " + message);

            AgentMove msg = JsonUtility.FromJson<AgentMove>(message);

            if (msg.id == agentID)
            {
                Vector2Int targetCords = new Vector2Int(msg.x, msg.y);

                if (gridManager.Grid[targetCords].ownerID == -1 || gridManager.Grid[targetCords].ownerID == agentID)
                {
                    gridManager.SetNodeOwner(targetCords, agentID);


                    if (targetCords.y == 11)
                    {
                        gridManager.SetNodeOwner(targetCords, agentID);
                        gridManager.SetNodeOwner(new Vector2Int(targetCords.x, 10), agentID);
                    }
                    else if (targetCords.y == 6)
                    {
                        gridManager.SetNodeOwner(new Vector2Int(targetCords.x, 7), agentID);
                        gridManager.SetNodeOwner(targetCords, agentID);
                    }


                    Debug.Log($"Agente {agentID} recibió orden para: {msg.x}, {msg.y}");
                    RecalculatePath(targetCords);
                }
                else
                {
                    int actualOwner = gridManager.Grid[targetCords].ownerID;
                    Debug.LogWarning($"Agente {agentID}: El cajón {targetCords} esta ocupado");
                    path.Clear();
                }
            }
        };


        ws.OnOpen += () =>
        {
            Debug.Log("WebSocket connected");
        };

        ws.OnError += (e) =>
        {
            Debug.LogError("WebSocket error: " + e);
        };

        ws.OnClose += (e) =>
        {
            Debug.Log("WebSocket closed");
        };

        await ws.Connect();
    }

    void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        ws.DispatchMessageQueue();
#endif
    }

    private Coroutine currentMoveCoroutine;
    void RecalculatePath(Vector2Int destino)
    {
        Vector2Int posicionActual = gridManager.GetCoordinatesFromPosition(transform.position);
        pathFinding.SetNewDestination(posicionActual, destino, agentID);

        if (currentMoveCoroutine != null)
        {
            StopCoroutine(currentMoveCoroutine);
        }

        path.Clear();

        List<Nodo> nuevaRuta = pathFinding.GetNewPath(posicionActual, agentID);
        if (nuevaRuta != null)
        {
            path = new List<Nodo>(nuevaRuta);
            currentMoveCoroutine = StartCoroutine(FollowPath());
        }
    }

    IEnumerator FollowPath()
    {
        Vector2Int targetPos = path[path.Count - 1].cords;
        Vector2Int entryNode = targetPos;

        if (targetPos.y == 6) entryNode.y = 7;
        else if (targetPos.y == 11) entryNode.y = 10;

        for (int i = 1; i < path.Count; i++)
        {
            Vector3 startPosition = selectedUnit.position;
            Vector2Int nextCoords = path[i].cords;
            Vector3 endPosition = gridManager.GetPositionFromCoordinates(nextCoords);
            float travelPercent = 0f;

            // Rotación hacia el siguiente punto
            Vector3 direction = (endPosition - startPosition).normalized;
            if (direction != Vector3.zero)
            {
                selectedUnit.rotation = Quaternion.LookRotation(direction);
            }

            // Movimiento entre nodos
            while (travelPercent < 1f)
            {
                Vector3 frontOffset = direction * 0.5f;
                Vector3 rayOrigin = selectedUnit.position + Vector3.up * 0.5f + frontOffset;
                Debug.DrawRay(rayOrigin, direction * distanciaSeguridad, Color.red);
                int layerMask = LayerMask.GetMask("Vehiculos");

                if (Physics.Raycast(rayOrigin, direction, out RaycastHit hit, distanciaSeguridad, layerMask))
                {
                    yield return null;
                    continue;
                }

                travelPercent += Time.deltaTime * movementSpeed;
                selectedUnit.position = Vector3.Lerp(startPosition, endPosition, travelPercent);
                yield return null;
            }

            Vector2Int oldCoords = gridManager.GetCoordinatesFromPosition(startPosition);
            gridManager.SetNodeWalkable(oldCoords, true);
        }

        selectedUnit.position = gridManager.GetPositionFromCoordinates(targetPos);

        gridManager.SetNodeWalkable(targetPos, false);
        gridManager.SetNodeWalkable(entryNode, false);

        if (targetPos.y == 6)
        {
            selectedUnit.rotation = Quaternion.Euler(0, 180f, 0); // Mirando hacia abajo
        }
        else
        {
            selectedUnit.rotation = Quaternion.Euler(0, 0f, 0);   // Mirando hacia arriba
        }

        // Bloqueo adicional de seguridad para nodos de transición (y=9 o y=7)
        if (targetPos.y == 11)
        {
            gridManager.SetNodeWalkable(new Vector2Int(targetPos.x, 10), false);
        }
    }

    async void OnApplicationQuit()
    {
        if (ws != null)
            await ws.Close();
    }
}

// 👇 Clase para parsear JSON
[System.Serializable]
public class AgentMove
{
    public int id;
    public int x;
    public int y;
}
