using UnityEngine;

public class CarrilCirculacion : MonoBehaviour
{
    public enum TileType
    {
        Road,
        Parking
    }
    public TileType tileType;

    public Vector2Int cords;
    GridManager gridManager;
    void Start()
    {
        gridManager = FindAnyObjectByType<GridManager>();
        int x = (int)transform.position.x;
        int z = (int)transform.position.z;

        cords = new Vector2Int(x / gridManager.UnityGridSize, z / gridManager.UnityGridSize);
    }

}
