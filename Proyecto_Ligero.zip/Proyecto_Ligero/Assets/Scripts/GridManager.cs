using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    [SerializeField] Vector2Int gridSize;
    [SerializeField] int unityGridSize;
    [SerializeField] LayerMask obstacleLayer;
    public int UnityGridSize { get { return unityGridSize; } }
    private int offset = -6;

    Dictionary<Vector2Int, Nodo> grid = new Dictionary<Vector2Int, Nodo>();
    public Dictionary<Vector2Int, Nodo> Grid { get { return grid; } }

    private void Awake()
    {
        CreateGrid();
        //ConfigurarSentidos();
    }

    public Nodo GetNodo(Vector2Int coordinates)
    {
        if (grid.ContainsKey(coordinates))
        {
            return grid[coordinates];
        }
        return null;
    }

    public void BlockNode(Vector2Int coordinates)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].walkable = false;
        }
    }

    public void ResetNodos()
    {
        foreach (KeyValuePair<Vector2Int, Nodo> entry in grid)
        {
            entry.Value.connectTo = null;
            entry.Value.explored = false;
            entry.Value.path = false;
        }
    }

    public Vector2Int GetCoordinatesFromPosition(Vector3 position)
    {
        Vector3 relativePos = position - transform.position;
        Vector2Int coordinates = new Vector2Int();

        coordinates.x = Mathf.RoundToInt(relativePos.x / 3);
        coordinates.y = Mathf.RoundToInt(relativePos.z / 3);

        return coordinates;
    }

    public Vector3 GetPositionFromCoordinates(Vector2 coordinates)
    {
        Vector3 position = new Vector3();

        position.x = coordinates.x * 3;
        position.z = coordinates.y * 3;

        return position + transform.position;
    }

    public void SetNodeWalkable(Vector2Int coordinates, bool isWalkable)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].walkable = isWalkable;
            if (isWalkable) grid[coordinates].ownerID = -1;
        }
    }

    private void CreateGrid()
    {
        for (int x = 0; x < gridSize.x; x++)
        {
            for (int y = 0; y < gridSize.y; y++)
            {
                Vector2Int cords = new Vector2Int(x, y);
                Vector3 worldPos = GetPositionFromCoordinates(cords);

                Vector3 checkPos = worldPos;
                checkPos.y = 1.0f;

                Collider[] colliders = Physics.OverlapSphere(checkPos, 1f, obstacleLayer);
                bool isBlocked = colliders.Length > 0;

                if (isBlocked)
                {
                    foreach (var col in colliders)
                    {
                        Debug.Log($"<color=red>Nodo {cords} BLOQUEADO por:</color> {col.name} en la capa {LayerMask.LayerToName(col.gameObject.layer)}");
                    }
                }

                grid.Add(cords, new Nodo(cords, !isBlocked));


                //GameObject cube= GameObject.CreatePrimitive(PrimitiveType.Cube);
                //Vector3 position = new Vector3(cords.x * 3, 0f, cords.y * 3);
                //cube.transform.position = position;
                //cube.transform.SetParent(transform);
            }
        }
    }

    public void SetNodeOwner(Vector2Int coordinates, int agentID)
    {
        if (grid.ContainsKey(coordinates))
        {
            grid[coordinates].ownerID = agentID;
        }
    }

    private void OnDrawGizmos()
    {
        if (grid == null) return;
        foreach (var item in grid)
        {
            Nodo n = item.Value;
            Vector3 pos = GetPositionFromCoordinates(item.Key);


            if (n.ownerID != -1) Gizmos.color = Color.blue;
            else if (!n.walkable) Gizmos.color = Color.red;
            else Gizmos.color = Color.white;

            /*

            else if (n.sentidoObligatorio != Vector2Int.zero) ;
            {
                // --- NUEVA LÓGICA: COLOR POR DIRECCIÓN ---
                if (n.sentidoObligatorio == Vector2Int.right) Gizmos.color = Color.yellow; // Derecha
                else if (n.sentidoObligatorio == Vector2Int.left) Gizmos.color = new Color(1f, 0.5f, 0f); // Naranja para Izquierda
                else if (n.sentidoObligatorio == Vector2Int.up) Gizmos.color = Color.green; // Arriba
                else if (n.sentidoObligatorio == Vector2Int.down) Gizmos.color = Color.magenta; // Abajo
            }

            */

            Gizmos.DrawSphere(pos, 0.5f);

            /* Flecha visual
            if (n.sentidoObligatorio != Vector2Int.zero)
            {
                Gizmos.color = Color.cyan;
                Vector3 direction3D = new Vector3(n.sentidoObligatorio.x, 0, n.sentidoObligatorio.y);
                Gizmos.DrawRay(pos, direction3D * 1.5f);
            }
            */
        }
    }

    public void ConfigurarSentidos()
    {
        foreach (var item in grid)
        {
            Vector2Int coords = item.Key;
            Nodo nodo = item.Value;

            //Hacia Abajo
            if (coords.y >= 3 && coords.y <= 4 && coords.x >= 17 && coords.y > 2 && coords.y < 8)
            {
                nodo.sentidoObligatorio = Vector2Int.right;
            }

            // Hacia Arriba
            if (coords.x <= 18 && coords.y > 3 && coords.y < 8)
            {
                nodo.sentidoObligatorio = Vector2Int.up;
            }

            //Hacia la Izquierda
            if (coords.y >= 8 && coords.y <= 9 && coords.x >= 23 && coords.x >= 12)
            {
                nodo.sentidoObligatorio = Vector2Int.left;
            }
        }
    }
}