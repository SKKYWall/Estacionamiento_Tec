import websockets
import json
import asyncio

connected_clients = set()

async def websocketHandler(websocket):
    print(f"Unity connected from: {websocket.remote_address}")
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            pass
    except websockets.exceptions.ConnectionClosed:
        print("Conexión cerrada por el cliente")
    finally:
        connected_clients.remove(websocket)
        print("Unity disconnected")

async def sendGoal(goal):
    if not connected_clients:
        print("No hay clientes conectados")
        return

    message = json.dumps(goal)
    for client in connected_clients:
        try:
            await client.send(message)
            print(f"Enviado a {client.remote_address}: {message}")
        except:
            print("Error al enviar mensaje al cliente")
    

async def startServer():
    server = await websockets.serve(
        websocketHandler,
        host="localhost",
        port=8765,
        ping_interval=None,
        ping_timeout=None
    )
    print("WebSocket server started on ws://localhost:8765")
    return server