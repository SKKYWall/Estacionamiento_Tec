from osbrain import Agent

class Car(Agent):
    def on_init(self):
        self.car_id = None
        self.goal = {"x": None, "y": None}

    def set_id(self, cid):
        self.car_id = cid

    def set_goal(self, goal):
        self.goal = goal
        self.log_info(f"Agente {self.car_id} direccionando a {self.goal}")

