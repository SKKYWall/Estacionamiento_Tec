class ParkingLot():
    def __init__(self):
        self.spots = [[False for _ in range(20)] for _ in range(50)] 
