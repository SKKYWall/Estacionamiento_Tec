from ParkingLot import ParkingLot
from Car import Car
from websocket_server import startServer, sendGoal
from osbrain import run_agent, run_nameserver
import random
import asyncio

async def main():
    ns = run_nameserver()
    parking_lot = ParkingLot()

    car_ids = [1, 2]
    cars = []

    for cid in car_ids:
        agent = run_agent(f"car_{cid}", base=Car)
        agent.set_id(cid)
        cars.append(agent)

    server= await startServer()
    print(f"Esperando a que conecten {len(car_ids)} coches")

    from websocket_server import connected_clients

    while len(connected_clients) < len(car_ids):
        await asyncio.sleep(1)
        print(f"Coches conectados: {len(connected_clients)}/{len(car_ids)}")

    print("Todos los coches conectados. Asignando lugares")
    await asyncio.sleep(2)

    cajones_disponibles = [
        {"x": 20, "y": 6}, {"x": 21, "y": 6}, 

    ]

    #
    #    {"x": 12, "y": 6}, {"x": 13, "y": 6}, {"x": 14, "y": 6}, {"x": 15, "y": 6}, {"x": 16, "y": 6},
     #   {"x": 19, "y": 6}, {"x": 20, "y": 6}, {"x": 21, "y": 6}, {"x": 22, "y": 6}, {"x": 23, "y": 6},
      #  {"x": 12, "y": 11}, {"x": 13, "y": 11}, {"x": 14, "y": 11}, {"x": 15, "y": 11}, {"x": 16, "y": 11},
       # {"x": 19, "y": 11}, {"x": 20, "y": 11}, {"x": 21, "y": 11}, {"x": 22, "y": 11}, {"x": 23, "y": 11}
    
    random.shuffle(cajones_disponibles)

    for i, agent in enumerate(cars):
        destino = cajones_disponibles[i]
        x_final = destino["x"]
        y_final = destino["y"]

        goal = {"id": car_ids[i], "x": x_final, "y": y_final}

        try:
            if 0 <= x_final < len(parking_lot.spots) and 0 <= y_final < len(parking_lot.spots[0]):
                parking_lot.spots[x_final][y_final] = True
        except IndexError:
            print(f"Aviso: El destino {x_final},{y_final} es externo a la matriz lógica.")

        try:
            agent.safe_call('set_goal', goal)
            print(f"Lógica de agente {car_ids[i]} actualizada")
        except Exception as e:
            print(f"Error al llamar a set_goal: {e}")

        await sendGoal(goal)
        await asyncio.sleep(1.5)
        print(f"Lugares enviados a los agentes {car_ids[i]}: {goal}")


    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("Cerrando servidor")
    finally:
        server.close()
        ns.shutdown()

if __name__ == "__main__":

    asyncio.run(main())
